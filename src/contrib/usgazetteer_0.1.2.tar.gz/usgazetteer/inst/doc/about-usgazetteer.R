## ---- results = "asis", echo=FALSE---------------------------------------
library(usgazetteer)
knitr::kable(head(state.areas.2010[,c(1:9,23,24)]), format = 'html')

## ---- results = "asis", echo=FALSE---------------------------------------
knitr::kable(data.frame(`Data Name`=names(gazetteer.2016)), format = 'html')

## ---- results = "asis"---------------------------------------------------
counties.2016 <- gazetteer.2016$Counties
knitr::kable(head(counties.2016[,c(1:4,9:12)]),  format = 'html')

