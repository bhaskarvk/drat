# usgazetteer 0.1.2

## new stuff

* added states and territories data from 2016 census

## new stuff

* added states and territories data
* Add Vignettes

# usgazetteer 0.1.0

## New Stuff

* First Release

